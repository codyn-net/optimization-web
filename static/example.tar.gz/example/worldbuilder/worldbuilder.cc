#include <optimization/dispatcher.hh>
#include <jessevdk/os/filesystem.hh>
#include <iostream>

using namespace std;
using namespace optimization::messages::task;
using namespace jessevdk::os;

class WorldBuilder : public optimization::TaskReader
{
};

int
main(int argc, char const* argv[])
{
	WorldBuilder builder;

	if (!builder.ReadRequest(cin))
	{
		cerr << "Could not read request" << endl;
		exit(1);
	}

	string world;
	if (!builder.Setting("world", world))
	{
		cerr << "Template world not set" << endl;
		exit(1);
	}

	// Generate world based on solution id
	stringstream s;

	s << world << "." << builder.Task().id();

	FileSystem::Copy(world, s.str());
	cout << s.str() << endl << flush;

	return 0;
}
