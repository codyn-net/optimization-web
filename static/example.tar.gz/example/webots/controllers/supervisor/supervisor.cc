#include <optimization/webots.hh>
#include <webots/Supervisor.hpp>

#include <iostream>
#include <sstream>
#include <cmath>

using namespace std;
using namespace optimization::messages::task;

#define TIMESTEP 32

class Controller : public webots::Supervisor
{
	double d_maxTime;
	double d_timeElapsed;
	double d_radius;
	webots::Field *d_robotTranslation;

	public:
		Controller();
		void Run();
	private:
		bool CheckDone();
		void SetupOptimization();
		void Update();
		double DistanceToOrigin();
};

Controller::Controller()
:
	d_maxTime(-1),
	d_timeElapsed(0),
	d_radius(0)
{
	SetupOptimization();

	// Store pointer to the translation field of the robot
	webots::Node *robot = getFromDef("ROBOT");
	d_robotTranslation = robot->getField("translation");
}

void
Controller::SetupOptimization()
{
	cerr << "Getting the opti" << endl;

	optimization::Webots &opti = optimization::Webots::Instance();

	if (opti)
	{
		cerr << "Yep, optimization mode" << endl;

		// In optimization mode, get the max-time setting to see how long
		// the simulation needs to run
		string maxTime;
		stringstream s;

		if (opti.Setting("max-time", maxTime))
		{
			s << maxTime;
			s >> d_maxTime;
		}
		else
		{
			// Default to 10 seconds of simulation
			d_maxTime = 10;
		}
	}
	else
	{
		cerr << "Nope, not optimizing" << endl;
	}
}

double
Controller::DistanceToOrigin()
{
	// Calculate the distance to the origin (x/z)
	double const *translation = d_robotTranslation->getSFVec3f();
	return sqrt(translation[0] * translation[0] + translation[2] * translation[2]);
}

bool
Controller::CheckDone()
{
	optimization::Webots &opti = optimization::Webots::Instance();

	// Check if we are done in optimization mode by comparing max time
	bool done = d_maxTime > 0 && d_timeElapsed > d_maxTime;

	if (done && opti)
	{
		// Send fitnesses when time is up in simulation mode
		map<string, double> fitnesses;

		fitnesses["radius"] = d_radius;
		fitnesses["from_origin"] = DistanceToOrigin();

		// Send the actual response
		if (opti.Setting("optiextractor"))
		{
			cout << "Radius = " << fitnesses["radius"] << ", from origin = " << fitnesses["from_origin"] << endl;
			cout << "Not sending response, because in optiextractor mode! Enjoy the show!" << endl;
		}
		else
		{
			opti.Respond(fitnesses);
		}
		return true;
	}

	return false;
}

void
Controller::Update()
{
	// Calculate the distance to the origin
	double dist = DistanceToOrigin();

	// Check if this exceeds the current maximum recorded distance
	if (dist > d_radius)
	{
		d_radius = dist;
	}
}

void
Controller::Run()
{
	while (step(TIMESTEP) != -1)
	{
		// Update maximum distance from origin
		Update();

		// Check if we are done simulation in optimization mode
		if (CheckDone())
		{
			break;
		}

		// Record elapsed time
		d_timeElapsed += TIMESTEP / 1000.0;
	}

	// Quit the simulation, nice for optimization mode
	optimization::Webots &opti = optimization::Webots::Instance();

	if (opti && !opti.Setting("optiextractor"))
	{
		simulationQuit();
	}
}

int
main(int    argc,
     char **argv)
{
	Controller controller;

	controller.Run();
	return 0;
}
