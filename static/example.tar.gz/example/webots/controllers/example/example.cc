#include <optimization/webots.hh>
#include <webots/DifferentialWheels.hpp>

#include <iostream>

using namespace std;
using namespace optimization::messages::task;

#define TIMESTEP 32

class Controller : public webots::DifferentialWheels
{
	double d_speedLeft;
	double d_speedRight;

	public:
		Controller();
		void Run();
	private:
		void SetupMotorSpeeds();
};

Controller::Controller()
{
	SetupMotorSpeeds();
}

void
Controller::SetupMotorSpeeds()
{
	cerr << "Checking for optimization mode" << endl;

	optimization::Webots &opti = optimization::Webots::Instance();

	// Default speeds, used when not in optimization mode
	d_speedLeft = 1000;
	d_speedRight = 1000;

	if (opti)
	{
		cerr << "Optimization mode, yes" << endl;

		// Read parameters for left and right speed in optimization mode
		Task::Parameter parameter;

		// Left speed parameter
		if (opti.Parameter("left", parameter))
		{
			d_speedLeft = parameter.value();
		}

		// Right speed parameter
		if (opti.Parameter("right", parameter))
		{
			d_speedRight = parameter.value();
		}
		
		cout << "Optimization mode: left = " << d_speedLeft << ", right = " << d_speedRight << endl;
	}
	else
	{
		cerr << "Not optimization mode :(" << endl;
	}
}

void
Controller::Run()
{
	double timeElapsed = 0;
	double maxTime;
	string setting;
	optimization::Webots &opti = optimization::Webots::Instance();

	if (opti && opti.Setting("max-time", setting))
	{
		stringstream s;
		s << setting;
		s >> maxTime;
	}
	else
	{
		// Default to 10 seconds of simulation
		maxTime = -1;
	}

	while (step(TIMESTEP) != -1)
	{
		timeElapsed += TIMESTEP / 1000.0;

		if (timeElapsed >= maxTime && maxTime >= 0)
		{
			setSpeed(0, 0);
		}
		else
		{
			setSpeed(d_speedLeft, d_speedRight);
		}
	}
}

int
main(int    argc,
     char **argv)
{
	Controller controller;
	
	controller.Run();
	return 0;
}
